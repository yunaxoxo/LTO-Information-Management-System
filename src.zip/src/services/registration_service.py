# Queries to execute on the database for the Vehicle Registration model
from src.db.db_connection import establish_connection

conn = establish_connection()
if conn:
    cursor = conn.cursor(
        dictionary=True
    )  # Use dictionary cursor for easier access to columns by name
else:
    print("Failed to establish database connection.")


# Create a new registration in the database
def register_new_vehicle_registration(registration):
    insert_query = """
    INSERT INTO vehicle_registrations (registration_number, registration_date, expiration_date, registration_status, plate_number)
    VALUES (?, ?, ?, ?, ?)"""
    cursor.execute(
        insert_query,
        (
            registration.registration_number,
            registration.registration_date,
            registration.expiration_date,
            registration.registration_status,
            registration.plate_number,
        ),
    )
    return "Vehicle registration created successfully."


# Read Vehicle Registrations based on criteria

# ==============================


def fetch_vehicle_registrations_by_criteria(filters):
    query = """

        SELECT * FROM vehicle_registrations
        WHERE (? = 'ALL' OR registration_number = ?)
        AND (? = 'ALL' OR registration_date = ?)
        AND (? = 'ALL' OR expiration_date = ?)
        AND (? = 'ALL' OR registration_status = ?)
        AND (? = 'ALL' OR plate_number = ?);"""

    cursor.execute(
        query,
        (
            filters.get("registration_number", "ALL"),
            filters.get("registration_number", "ALL"),
            filters.get("registration_date", "ALL"),
            filters.get("registration_date", "ALL"),
            filters.get("expiration_date", "ALL"),
            filters.get("expiration_date", "ALL"),
            filters.get("registration_status", "ALL"),
            filters.get("registration_status", "ALL"),
            filters.get("plate_number", "ALL"),
            filters.get("plate_number", "ALL"),
        ),
    )

    return cursor.fetchall()


# =====================================

# Update Vehicle Registration information


def update_vehicle_registration(registration):
    update_query = """
        UPDATE vehicle_registrations
        SET registration_date = ?, expiration_date = ?, registration_status = ?, plate_number = ?
        WHERE registration_number = ?"""
    cursor.execute(
        update_query,
        (
            registration.registration_date,
            registration.expiration_date,
            registration.registration_status,
            registration.plate_number,
            registration.registration_number,
        ),
    )
    return "Vehicle registration information updated successfully."


# Delete a vehicle registration from the database via registration number
def delete_vehicle_registration(registration_number):
    delete_query = "DELETE FROM vehicle_registrations WHERE registration_number = ?"
    cursor.execute(delete_query, registration_number)
    return "Vehicle registration deleted successfully."
