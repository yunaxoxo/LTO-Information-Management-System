# Queries to execute on the database for the Driver model
from src.db.db_connection import establish_connection

conn = establish_connection()
if conn:
    cursor = conn.cursor(
        dictionary=True
    )  # Use dictionary cursor for easier access to columns by name
else:
    print("Failed to establish database connection.")


# Create a new driver in the database
def register_new_driver(driver):
    insert_query = """
                INSERT INTO drivers (full_name, license_number, license_type, license_status, birthday, sex, address, issuance_date, expiration_date)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"""
    cursor.execute(
        insert_query,
        (
            driver.full_name,
            driver.license_number,
            driver.license_type,
            driver.license_status,
            driver.birthday,
            driver.sex,
            driver.address,
            driver.issuance_date,
            driver.expiration_date,
        ),
    )

    return "Driver registered successfully."


# Read drivers based on criteria

# ==============================


def fetch_drivers_by_criteria(filters):
    # Fetch drivers based on selected criteria (license type, license status, sex, age range)
    query = """

        SELECT * FROM drivers
        WHERE (? = 'ALL' OR license_type = ?)
        AND (? = 'ALL' OR license_status = ?)
        AND (? = 'ALL' OR sex = ?)
        AND (TIMESTAMPDIFF(YEAR, birthday, CURDATE()) BETWEEN ? AND ?) OR ? = 'ALL';"""

    cursor.execute(
        query,
        (
            filters.get("license_type", "ALL"),
            filters.get("license_type", "ALL"),
            filters.get("license_status", "ALL"),
            filters.get("license_status", "ALL"),
            filters.get("sex", "ALL"),
            filters.get("sex", "ALL"),
            filters.get("min_age", "ALL"),
            filters.get("max_age", "ALL"),
            filters.get("min_age", "ALL"),
        ),
    )

    return cursor.fetchall()


def fetch_invalid_licenses():
    query = "SELECT * FROM drivers WHERE license_status IN ('Expired', 'Suspended')"
    cursor.execute(query)
    return cursor.fetchall()


# =====================================

# Update driver information


def update_driver_info(driver):
    update_query = """
        UPDATE drivers
        SET full_name = ?, license_type = ?, license_status = ?, birthday = ?, sex = ?, address = ?, issuance_date = ?, expiration_date = ? 
        WHERE license_number = ?"""
    cursor.execute(
        update_query,
        (
            driver.full_name,
            driver.license_type,
            driver.license_status,
            driver.birthday,
            driver.sex,
            driver.address,
            driver.issuance_date,
            driver.expiration_date,
            driver.license_number,
        ),
    )
    return "Driver information updated successfully."


# Delete a driver from the database via license number
def delete_driver(license_number):
    delete_query = "DELETE FROM drivers WHERE license_number = ?"
    cursor.execute(delete_query, license_number)
    return "Driver deleted successfully."
