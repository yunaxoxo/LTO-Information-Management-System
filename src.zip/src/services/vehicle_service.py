# Queries to execute on the database for the Vehicle model
from src.db.db_connection import establish_connection

conn = establish_connection()
if conn:
    cursor = conn.cursor(
        dictionary=True
    )  # Use dictionary cursor for easier access to columns by name
else:
    print("Failed to establish database connection.")


# Create a new vehicle in the database
def register_new_vehicle(vehicle):
    insert_query = """
                INSERT INTO vehicles (plate_number, engine_number, chassis_number, make, model, year, color, vehicle_type, license_number)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"""
    cursor.execute(
        insert_query,
        (
            vehicle.plate_number,
            vehicle.engine_number,
            vehicle.chassis_number,
            vehicle.make,
            vehicle.model,
            vehicle.year,
            vehicle.color,
            vehicle.vehicle_type,
            vehicle.license_number,
        ),
    )

    return "Vehicle registered successfully."


# Read vehicles based on criteria

# ==============================


def fetch_vehicles_by_criteria(filters):
    query = """
        SELECT * FROM vehicles
        WHERE (? = 'ALL' OR make = ?)
        AND (? = 'ALL' OR model = ?)
        AND (? = 'ALL' OR year = ?)
        AND (? = 'ALL' OR color = ?)
        AND (? = 'ALL' OR vehicle_type = ?)
        AND (? = 'ALL' OR license_number = ?);"""
    cursor.execute(
        query,
        filters.get("make", "ALL"),
        filters.get("make", "ALL"),
        filters.get("model", "ALL"),
        filters.get("model", "ALL"),
        filters.get("year", "ALL"),
        filters.get("year", "ALL"),
        filters.get("color", "ALL"),
        filters.get("color", "ALL"),
        filters.get("vehicle_type", "ALL"),
        filters.get("vehicle_type", "ALL"),
        filters.get("license_number", "ALL"),
        filters.get("license_number", "ALL"),
    )


def get_expired_vehicles(date_cutoff):
    query = """
        SELECT v.*
        FROM vehicles v
        JOIN vehicle_registrations r
        ON v.plate_number = r.plate_number
        WHERE r.expiration_date < ?;"""

    cursor.execute(query, date_cutoff)
    return cursor.fetchall()


# =====================================

# Update vehicle information


def update_vehicle_info(vehicle):
    update_query = """
    UPDATE vehicles
    SET engine_number = ?, chassis_number = ?, make = ?, model = ?, year = ?,
    color = ?, vehicle_type = ?, license_number = ?
    WHERE plate_number = ?"""
    cursor.execute(
        update_query,
        (
            vehicle.engine_number,
            vehicle.chassis_number,
            vehicle.make,
            vehicle.model,
            vehicle.year,
            vehicle.color,
            vehicle.vehicle_type,
            vehicle.license_number,
            vehicle.plate_number,
        ),
    )
    return "Vehicle information updated successfully."


# Delete a vehicle from the database via plate number
def delete_vehicle(plate_number):
    delete_query = "DELETE FROM vehicles WHERE plate_number = ?"
    cursor.execute(delete_query, plate_number)
    return "Vehicle deleted successfully."
