# Queries to execute on the database for the Traffic Violation model
from src.db.db_connection import establish_connection

conn = establish_connection()
if conn:
    cursor = conn.cursor(
        dictionary=True
    )  # Use dictionary cursor for easier access to columns by name
else:
    print("Failed to establish database connection.")


# Create a new registration in the database
def register_new_traffic_violation(violation):
    insert_query = """
    INSERT INTO traffic_violations (violation_id, top_number, violation_type, violation_date, location, apprehending_officer, fine_amount, license_number, plate_number)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"""
    cursor.execute(
        insert_query,
        (
            violation.violation_id,
            violation.top_number,
            violation.violation_type,
            violation.violation_date,
            violation.location,
            violation.apprehending_officer,
            violation.fine_amount,
            violation.license_number,
            violation.plate_number,
        ),
    )
    return "Traffic violation recorded successfully."


# Read Traffic Violations based on criteria

# ==============================


def fetch_traffic_violations_by_criteria(filters):
    query = """

        SELECT * FROM traffic_violations
        WHERE (? = 'ALL' OR violation_id = ?)
        AND (? = 'ALL' OR top_number = ?)
        AND (? = 'ALL' OR violation_type = ?)
        AND (? = 'ALL' OR violation_date = ?)
        AND (? = 'ALL' OR location = ?)
        AND (? = 'ALL' OR apprehending_officer = ?)
        AND (? = 'ALL' OR fine_amount = ?)
        AND (? = 'ALL' OR license_number = ?)
        AND (? = 'ALL' OR plate_number = ?);"""

    cursor.execute(
        query,
        (
            filters.get("violation_id", "ALL"),
            filters.get("violation_id", "ALL"),
            filters.get("top_number", "ALL"),
            filters.get("top_number", "ALL"),
            filters.get("violation_type", "ALL"),
            filters.get("violation_type", "ALL"),
            filters.get("violation_date", "ALL"),
            filters.get("violation_date", "ALL"),
            filters.get("location", "ALL"),
            filters.get("location", "ALL"),
            filters.get("apprehending_officer", "ALL"),
            filters.get("apprehending_officer", "ALL"),
            filters.get("fine_amount", "ALL"),
            filters.get("fine_amount", "ALL"),
            filters.get("license_number", "ALL"),
            filters.get("license_number", "ALL"),
            filters.get("plate_number", "ALL"),
            filters.get("plate_number", "ALL"),
        ),
    )

    return cursor.fetchall()


def fetch_traffic_violation_by_driver(license_number, start_date, end_date):
    query = "SELECT * FROM traffic_violations WHERE license_number = ? AND violation_date BETWEEN ? AND ?;"
    cursor.execute(query, (license_number, start_date, end_date))
    return cursor.fetchall()


def fetch_traffic_violation_by_violation_type(plate_number, start_date, end_date):
    query = """SELECT violation_type,
        COUNT(*) AS total_violations
        FROM traffic_violations
        WHERE violation_date BETWEEN ? AND ?
        GROUP BY violation_type;"""
    cursor.execute(query, (plate_number, start_date, end_date))
    return cursor.fetchall()


def fetch_traffic_violation_by_location(location, start_date, end_date):
    query = (
        """SELECT * FROM traffic_violations WHERE location LIKE CONCAT('%', ?, '%');"""
    )
    cursor.execute(query, (location, start_date, end_date))
    return cursor.fetchall()


# =====================================

# Update Traffic Violation information


def update_traffic_violation(violation):
    update_query = """
        UPDATE traffic_violations
        SET violation_type = ?, violation_date = ?, location = ?, apprehending_officer = ?, fine_amount = ?, license_number = ?, plate_number = ?
        WHERE top_number = ?"""
    cursor.execute(
        update_query,
        (
            violation.violation_type,
            violation.violation_date,
            violation.location,
            violation.apprehending_officer,
            violation.fine_amount,
            violation.license_number,
            violation.plate_number,
            violation.top_number,
        ),
    )
    return "Traffic violation information updated successfully."


# Delete a traffic violation from the database via violation ID
def delete_traffic_violation(top_number):
    delete_query = "DELETE FROM traffic_violations WHERE top_number = ?"
    cursor.execute(delete_query, top_number)
    return "Traffic violation deleted successfully."
