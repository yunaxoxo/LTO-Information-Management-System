import mariadb
import streamlit as st


@st.cache_resource  # Caches the connection resource to avoid reconnecting on every function call
def get_connection():
    return mariadb.connect(
        host=st.secrets.DB_CREDENTIALS.DB_HOST,
        user=st.secrets.DB_CREDENTIALS.DB_USER,
        password=st.secrets.DB_CREDENTIALS.DB_PASSWORD,
        database=st.secrets.DB_CREDENTIALS.DB_NAME,
        port=st.secrets.DB_CREDENTIALS.DB_PORT,
    )


def establish_connection():
    try:
        conn = get_connection()
        return conn
    except mariadb.Error as e:
        st.error(f"Error connecting to the database: {e}")
        return None
