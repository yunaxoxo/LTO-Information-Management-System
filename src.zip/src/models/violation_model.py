# Data Structure for Violation Model
class Violation:
    def __init__(
        self,
        violation_id,
        top_number,
        violation_type,
        violation_date,
        location,
        apprehending_officer,
        fine_amount,
        license_number,
        plate_number,
    ):
        self.violation_id = violation_id
        self.top_number = top_number
        self.violation_type = violation_type
        self.violation_date = violation_date
        self.location = location
        self.apprehending_officer = apprehending_officer
        self.fine_amount = fine_amount
        self.license_number = license_number
        self.plate_number = plate_number

    def __str__(self):
        return f"Violation(Violation ID: {self.violation_id}, Top Number: {self.top_number}, Violation Type: {self.violation_type}, Violation Date: {self.violation_date}, Location: {self.location}, Apprehending Officer: {self.apprehending_officer}, Fine Amount: {self.fine_amount}, License Number: {self.license_number}, Plate Number: {self.plate_number})"
