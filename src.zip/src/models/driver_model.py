# Data Structure for Driver Model
class Driver:
    def __init__(
        self,
        full_name,
        license_number,
        license_type,
        license_status,
        birthday,
        sex,
        address,
        issuance_date,
        expiration_date,
    ):
        self.full_name = full_name
        self.license_number = license_number
        self.license_type = license_type
        self.license_status = license_status
        self.birthday = birthday
        self.sex = sex
        self.address = address
        self.issuance_date = issuance_date
        self.expiration_date = expiration_date

    def __str__(self):
        return f"Driver(Name: {self.full_name}, License Number: {self.license_number}, License Type: {self.license_type}, License Status: {self.license_status}, Birthday: {self.birthday}, Sex: {self.sex}, Address: {self.address}, Issuance Date: {self.issuance_date}, Expiration Date: {self.expiration_date})"
