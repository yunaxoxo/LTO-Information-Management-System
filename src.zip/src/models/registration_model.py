# Data Structure for Registration Model
class Registration:
    def __init__(
        self,
        registration_number,
        registration_date,
        expiration_date,
        registration_status,
        plate_number,
    ):
        self.registration_number = registration_number
        self.registration_date = registration_date
        self.expiration_date = expiration_date
        self.registration_status = registration_status
        self.plate_number = plate_number

    def __str__(self):
        return f"Registration(Registration Number: {self.registration_number}, Registration Date: {self.registration_date}, Expiration Date: {self.expiration_date}, Registration Status: {self.registration_status}, Plate Number: {self.plate_number})"
