# Data Structure for Vehicle Model
class Vehicle:
    def __init__(
        self,
        plate_number,
        engine_number,
        chassis_number,
        make,
        model,
        year,
        color,
        vehicle_type,
        license_number,
    ):
        self.plate_number = plate_number
        self.make = make
        self.model = model
        self.year = year
        self.color = color
        self.engine_number = engine_number
        self.chassis_number = chassis_number
        self.vehicle_type = vehicle_type
        self.license_number = license_number

    def __str__(self):
        return f"Vehicle(Plate Number: {self.plate_number}, Make: {self.make}, Model: {self.model}, Year: {self.year}, Color: {self.color}, Engine Number: {self.engine_number}, Chassis Number: {self.chassis_number}, Vehicle Type: {self.vehicle_type}, License Number: {self.license_number})"
