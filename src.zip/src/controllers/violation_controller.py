# traffic violation controller for handling violation-related operations
from models.violation_model import Violation
from services import violation_service


def create_violation_object(violation_data: dict) -> Violation:
    return Violation(
        violation_id=violation_data.get("violation_id", "").strip(),
        top_number=violation_data.get("top_number", "").strip(),
        violation_type=violation_data.get("violation_type", "").strip(),
        violation_date=violation_data.get("violation_date", "").strip(),
        location=violation_data.get("location", "").strip(),
        apprehending_officer=violation_data.get("apprehending_officer", "").strip(),
        fine_amount=violation_data.get("fine_amount", 0),
        license_number=violation_data.get("license_number", "").strip(),
        plate_number=violation_data.get("plate_number", "").strip(),
    )


def create_violation(violation_data: dict) -> str:
    violation = create_violation_object(violation_data)
    return violation_service.record_new_traffic_violation(violation)


def get_violation_by_criteria(filters: dict) -> dict:
    return violation_service.fetch_traffic_violations_by_criteria(filters)


def get_violation_by_driver(
    license_number: str, start_date: str, end_date: str
) -> dict:
    return violation_service.fetch_traffic_violation_by_driver(
        license_number, start_date, end_date
    )


def get_violation_by_type(violation_type: str, start_date: str, end_date: str) -> dict:
    return violation_service.fetch_traffic_violation_by_type(
        violation_type, start_date, end_date
    )


def get_violation_by_location(location: str, start_date: str, end_date: str) -> dict:
    return violation_service.fetch_traffic_violation_by_location(
        location, start_date, end_date
    )


def update_violation(violation_data: dict) -> str:
    violation = create_violation_object(violation_data)
    return violation_service.update_traffic_violation(violation)


def delete_violation(top_number: str) -> str:
    return violation_service.delete_traffic_violation(top_number)
