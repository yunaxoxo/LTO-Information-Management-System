# driver controller for handling driver-related operations
from models.driver_model import Driver
from services import driver_service


def create_driver_object(driver_data: dict) -> Driver:
    # Creates driver object to use in the database operations
    driver_object = Driver(
        full_name=driver_data.get("full_name", "").strip(),
        license_number=driver_data.get("license_number", "").strip(),
        license_type=driver_data.get("license_type", "").strip(),
        license_status=driver_data.get("license_status", "").strip(),
        birthday=driver_data.get("birthday").isoFormat()
        if driver_data.get("birthday")
        else None,
        sex=driver_data.get("sex", "").strip(),
        address=driver_data.get("address", "").strip(),
        issuance_date=driver_data.get("issuance_date", "").strip(),
        expiration_date=driver_data.get("expiration_date", "").strip(),
    )
    return driver_object


def create_driver(driver_data: dict) -> str:
    # Creates driver object to use in the database operations
    driver_object = create_driver_object(driver_data)
    driver = driver_service.register_new_driver(driver_object)
    return driver


# Retrieves the rows which match the criteria selected by the user in the UI and returns it to the UI for display
def get_drivers_by_criteria(user_selections: dict) -> dict:
    return driver_service.fetch_drivers_by_criteria(user_selections)


def get_invalid_licenses() -> dict:
    return driver_service.fetch_invalid_licenses()


def update_driver(driver_data: dict) -> str:
    driver = create_driver_object(driver_data)
    return driver_service.update_driver_info(driver)


# Pass the license number for unique identification of the driver to be deleted and return the result of the delete operation to the UI for display
def delete_driver(license_number: str) -> str:
    return driver_service.delete_driver(license_number)
