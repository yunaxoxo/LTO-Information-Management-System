# vehicle registration controller for handling registration-related operations
from models.registration_model import Registration
from services import registration_service


def create_vehicle_registration_object(registration_data: dict) -> Registration:
    return Registration(
        registration_number=registration_data.get("registration_number", "").strip(),
        registration_date=registration_data.get("registration_date", "").strip(),
        expiration_date=registration_data.get("expiration_date", "").strip(),
        registration_status=registration_data.get("registration_status", "").strip(),
        plate_number=registration_data.get("plate_number", "").strip(),
    )


def create_vehicle_registration(registration_data: dict) -> str:
    registration = create_vehicle_registration_object(registration_data)
    return registration_service.register_new_vehicle_registration(registration)


def get_vehicles_registrations_by_criteria(filters: dict) -> dict:
    return registration_service.fetch_vehicle_registrations_by_criteria(filters)


def update_registration(registration_data: dict) -> str:
    registration = create_vehicle_registration_object(registration_data)
    return registration_service.update_vehicle_registration(registration)


def delete_registration(registration_number: str) -> str:
    return registration_service.delete_vehicle_registration(registration_number)
