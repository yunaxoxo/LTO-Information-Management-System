# vehicle controller for handling vehicle-related operations
from models.vehicle_model import Vehicle
from services import vehicle_service


def create_vehicle_object(vehicle_data: dict) -> Vehicle:
    return Vehicle(
        plate_number=vehicle_data.get("plate_number", "").strip(),
        engine_number=vehicle_data.get("engine_number", "").strip(),
        chassis_number=vehicle_data.get("chassis_number", "").strip(),
        make=vehicle_data.get("make", "").strip(),
        model=vehicle_data.get("model", "").strip(),
        year=vehicle_data.get("year", "").strip(),
        color=vehicle_data.get("color", "").strip(),
        vehicle_type=vehicle_data.get("vehicle_type", "").strip(),
        license_number=vehicle_data.get("license_number", "").strip(),
    )


def create_vehicle(vehicle_data):
    vehicle = create_vehicle_object(vehicle_data)
    return vehicle_service.register_new_vehicle(vehicle)


def get_vehicles_by_criteria(user_selections: dict) -> dict:
    return vehicle_service.fetch_vehicles_by_criteria(user_selections)


def get_expired_vehicles(date_cutoff) -> dict:
    return vehicle_service.get_expired_vehicles(date_cutoff)


def update_vehicle(vehicle_data: dict) -> str:
    vehicle = create_vehicle_object(vehicle_data)
    return vehicle_service.update_vehicle_info(vehicle)


def delete_vehicle(plate_number: str) -> str:
    return vehicle_service.delete_vehicle(plate_number)
